#!/usr/bin/perl

print "1..1\n";
print "ok 1\n";
