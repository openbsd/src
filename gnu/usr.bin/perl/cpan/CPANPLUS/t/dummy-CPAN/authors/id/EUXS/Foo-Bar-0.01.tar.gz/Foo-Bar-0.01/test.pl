BEGIN { print "1..1\n" };
use Foo::Bar;
print "ok 1\n";
