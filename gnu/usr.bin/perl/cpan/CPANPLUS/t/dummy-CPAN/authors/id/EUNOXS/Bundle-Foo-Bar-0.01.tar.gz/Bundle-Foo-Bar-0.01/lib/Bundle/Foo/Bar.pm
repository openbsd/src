package Bundle::Foo::Bar;

$VERSION = "0.01";

1;

__END__

=head1 NAME

Bundle::Foo::Bar 

=head1 CONTENTS

Foo::Bar::EU::XS    0.01

Foo::Bar::EU::NOXS  0.01

Foo::Bar::MB::XS    0.01

Foo::Bar::MB::NOXS  0.01

Cwd                 0.01

=head1 AUTHOR

ExtUtils::MakeMaker No XS Code <cpanplus@example.com>

=cut 


__END__

